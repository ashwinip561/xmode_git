import crossconnect.common.SignalGroups;

spec DcViVMeasOnly {

// add action declarations here
    action voltMeas1;
    action voltMeas2;
    action voltMeas3;
    action currForceVoltMeas1;
    action currForceVoltMeas2;

    // dcVI settings
    setup dcVI D01 + D02 {
        level.vforce = 0.0V;
        level.irange = 1.0uA;
        action vmeas voltMeas1 {
            vrange = 3V;
        }
        action vmeas voltMeas2 {
            vrange = 3V;
        }
        action vmeas voltMeas3 {
            vrange = 3V;
        }
        action iforceVmeas currForceVoltMeas1 {
            vrange = 3V;
            forceValue = 1.0uA;
        }
        action iforceVmeas currForceVoltMeas2 {
            vrange = 3V;
            forceValue = 1.0uA;
        }
    }

    action force1_1V;
    action force1_2V;
    action force1_3V;
    action force1_4V;
    action force1_5V;
    action force2_1V;
    action force2_2V;
    action force2_3V;
    action force2_4V;
    action force2_5V;
    setup dcVI R01 + R02 {
        level.vforce = 0.0V;
        level.iclamp = 1.0uA;
        action vforce force1_1V {
            forceValue = 1.1V;
        }
        action vforce force1_2V {
            forceValue = 1.2V;
        }
        action vforce force1_3V {
            forceValue = 1.3V;
        }
        action vforce force1_4V {
            forceValue = 1.4V;
        }
        action vforce force1_5V {
            forceValue = 1.5V;
        }
        action vforce force2_1V {
            forceValue = 2.1V;
        }
        action vforce force2_2V {
            forceValue = 2.2V;
        }
        action vforce force2_3V {
            forceValue = 2.3V;
        }
        action vforce force2_4V {
            forceValue = 2.4V;
        }
        action vforce force2_5V {
            forceValue = 2.5V;
        }
    }

}
