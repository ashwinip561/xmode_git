import crossconnect.common.SignalGroups;

spec DcViActions {
    action voltMeas1;
    action voltMeas2;
    action voltMeas3;
    action currMeas1;
    action currMeas2;
    setup dcVI D01 {
        level.vforce = 0.0V;
        level.irange = 3.0uA;
        action vmeas voltMeas1 {
            vrange = 3V;
            waitTime = 0.7ms;
        }
        action vmeas voltMeas2 {
            vrange = 3V;
            waitTime = 0.7ms;
        }
        action vmeas voltMeas3 {
            vrange = 3V;
            waitTime = 0.7ms;
        }
    }
    setup dcVI D02 {
        level.vforce = 0.0V;
        level.irange = 3uA;
        action vmeas voltMeas1 {
            vrange = 3V;
            waitTime = 0.7ms;
        }
        action vmeas voltMeas2 {
            vrange = 3V;
            waitTime = 0.7ms;
        }
        action vmeas voltMeas3 {
            vrange = 3V;
            waitTime = 0.7ms;
        }
        action imeas currMeas1 {
            irange = 3.0uA;
        }
        action imeas currMeas2 {
            irange = 3.0uA;
        }
    }

    action force1_1V;
    action force1_2V;
    action force1_3V;
    action force1_4V;
    action force1_5V;
    setup dcVI R01 {
        level.vforce = 0.0V;
        level.irange = 20mA;
        action vforce force1_1V {
            forceValue = 1.105V;
        }
        action vforce force1_2V {
            forceValue = 1.205V;
        }
        action vforce force1_3V {
            forceValue = 1.305V;
        }
        action vforce force1_4V {
            forceValue = 1.405V;
        }
        action vforce force1_5V {
            forceValue = 1.505V;
        }
    }

    action force2_1uA;
    action force2_2V;
    action force2_3V;
    action force2_4uA;
    action force2_5uA;
    setup dcVI R02 {
        level.vforce = 0.0V;
        level.irange = 20mA;
        action iforce force2_1uA {
            forceValue = 2.102uA;
            vclampHigh = 0.25V;
            vclampLow = 0.0V;
        }
        action vforce force2_2V {
            forceValue = 2.208V;
            irange = 20mA;
        }
        action vforce force2_3V {
            forceValue = 2.308V;
            irange = 20mA;
        }
        action iforce force2_4uA {
            forceValue = 2.402uA;
            vclampHigh = 0.25V;
            vclampLow = 0.0V;
        }
        action iforce force2_5uA {
            forceValue = 2.502uA;
            vclampHigh = 0.25V;
            vclampLow = 0.0V;
        }
    }

}
