import crossconnect.common.SignalGroups;

spec DcViLab {
    // declarations
    set timingSet_1;
    set levelSet_1;
    // add action declarations here

    // variables
    var Time per;
    var Time t_drive;
    var Time t_exp;
    var Voltage vcc;
    var Voltage IV_Swing;
    var Voltage OV_Swing;

    // timing settings
    per        = 10e-06 s;
    t_drive    = per / 4;
    t_exp      = per - 2 ns;

    // level settings
    vcc        = 1.4 V;
    IV_Swing   = 1.4 V;
    OV_Swing   = 0.4 V;

    // dcVI settings
    setup dcVI D00 {
        // add actions here
    }

    setup dcVI R00 {
        // add actions here
    }

    // add digital signals D01 and R01 here

}
