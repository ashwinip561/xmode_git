import crossconnect.common.SignalGroups;

spec SpecFileLabTiming {
    set timingSet_1;
    var Time per;
    var Time t_drive;
    var Time t_exp;

    setup digInOut gD00_D03 + gR00_R03 {
        set timing timingSet_1 {
            period = per;
            d1 = t_drive;
            r1 = t_exp;
        }
        //
        // Lab : Add default wavetable with xModes = 1, later change it to xModes = 2
        //

    }

    setup digInOut gD04_D07 + gR04_R07 {
        set timing timingSet_1 {
            period = per; // Lab: change period here
            d1 = t_drive;
            r1 = t_exp;
        }
        //
        // Lab : Add default wavetable with xModes = 1
        //

    }

    setup digInOut gD08_D15 + gR08_R15 {
        set timing timingSet_1 {
            period = per; // Lab: change period here
            d1 = t_drive;
            r1 = t_exp;
        }
        //
        // Lab : Add default wavetable with xModes = 1, afterwards CTRL-SHIFT-F
        //

    }

}
