package testMethods.acLib;

import xoc.dsa.DeviceSetupFactory;
import xoc.dsa.IDeviceSetup;
import xoc.dsa.ISetupDcVI;
import xoc.dsa.ISetupDcVI.IImeas;
import xoc.dsa.ISetupDigInOut;
import xoc.dsa.ISetupWavetable;
import xoc.dta.TestMethod;
import xoc.dta.annotations.In;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IDcVIResults;
import xoc.dta.resultaccess.IDigInOutResults;
import xoc.dta.testdescriptor.IFunctionalTestDescriptor;
import xoc.dta.testdescriptor.IParametricTestDescriptor;

/**
 * This is a basic test method that executes a functional test.
 * It runs an operating sequence that executes a digital pattern and then measures a current.
 *
 */
public class ProgrammaticTestSetup extends TestMethod {

    /** Main object for the test execution */
    public IMeasurement measurement;
    /** Functional test descriptor for datalog */
    public IFunctionalTestDescriptor myFtd;
    /** Parametric test descriptor for datalog */
    public IParametricTestDescriptor myPtd;
    /** Path to the specification file that should be imported */
    @In public String specFileToImport = "crossconnect.common.SignalGroups";
    /** Path to the pattern that should be executed */
    @In public String patternToExecute = "crossconnect.digitalTests.patterns.Functional00_03x1";
    /** Signals of the pattern that should be executed */
    @In public String signalsInPattern = "D00+D01+D02+D03+R00+R01+R02+R03";
    /** Signals to measure current */
    @In public String signalsToMeasure = "D15";

    @Override
    public void setup() {
        // Create Setup API instance that is used to generate setup files
        IDeviceSetup deviceSetup = DeviceSetupFactory.createInstance();

        // Setup digital signals: levels, timing, wavetable
        ISetupDigInOut digIOSetup = deviceSetup.addDigInOut(signalsInPattern);
        digIOSetup.level("myLevelSet").setVil(0.0).setVih(1.0);
        digIOSetup.timing("myTimingSet").setPeriod(0.1e-6).setD1(0).setR1(0.05e-6);
        setupWavetable(digIOSetup);

        // Setup dcVI signals: levels, 'imeas' action
        ISetupDcVI dcVISetup = deviceSetup.addDcVI(signalsToMeasure);
        dcVISetup.level().setVforce(0.0);
        IImeas myAction = dcVISetup.imeas("myMeasureAction").setIrange(10e-6);

        // Import specification file given in test flow
        deviceSetup.importSpec(specFileToImport);

        // Create operating sequence
        deviceSetup.patternCall(patternToExecute);
        deviceSetup.actionCall(myAction);

        // Make the generated setup to become valid for the current measurement
        measurement.setSetups(deviceSetup);
    }

    @Override
    public void update() {
        // Enable the cycle pass/fail when log level is 30 and higher.
        if (myFtd.getLogLevel() >= 30) {
            measurement.digInOut(signalsInPattern).result().cyclePassFail().setEnabled(true);
        }
    }

    @Override
    public void execute() {
        // run measurement
        measurement.execute();

        // protect results to be not overwritten
        IDigInOutResults passFailResults = measurement.digInOut(signalsInPattern).preserveResults(myFtd);
        IDcVIResults currentMeasureResults = measurement.dcVI(signalsToMeasure).preserveResults();

        // next test suite can start and use tester resources
        releaseTester();

        // for all sites: check pass/fail and send results to datalog
        myFtd.evaluate(passFailResults);
        myPtd.evaluate(currentMeasureResults.imeas("myMeasureAction").getCurrent(), 0);
    }

    private ISetupDigInOut setupWavetable(ISetupDigInOut digIOSetup) {
        ISetupWavetable newWvt = digIOSetup.addWavetable("myWavetable", 1);
        newWvt.addStateCharDescription('0',
                ISetupWavetable.DriveAction.F00,
                ISetupWavetable.ReceiveAction.X);
        newWvt.addStateCharDescription('1',
                ISetupWavetable.DriveAction.F10,
                ISetupWavetable.ReceiveAction.X);
        newWvt.addStateCharDescription('Z',
                ISetupWavetable.DriveAction.FNZ,
                ISetupWavetable.ReceiveAction.X);
        newWvt.addStateCharDescription('L',
                ISetupWavetable.DriveAction.FNZ,
                ISetupWavetable.ReceiveAction.L);
        newWvt.addStateCharDescription('H',
                ISetupWavetable.DriveAction.FNZ,
                ISetupWavetable.ReceiveAction.H);

        return digIOSetup;
    }
}

