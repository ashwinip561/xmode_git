package testMethods.acLib;

import xoc.dta.ParameterGroup;
import xoc.dta.ParameterGroupCollection;
import xoc.dta.TestMethod;
import xoc.dta.UncheckedDTAException;
import xoc.dta.annotations.In;
import xoc.dta.annotations.Out;
import xoc.dta.datatypes.MultiSiteBoolean;
import xoc.dta.measurement.IMeasurement;
import xoc.dta.resultaccess.IMeasurementResult;
import xoc.dta.testdescriptor.IFunctionalTestDescriptor;

/**
 * This is a basic test method that executes a functional
 * test of bursted patterns.
 * It runs an operating sequence that executes a sequence
 * of digital patterns.
 * The digital patterns are listed in a parameter group.
 * This group is an input parameter to this test method.
 * The test method provides the pass/fail results of
 * the execution as output parameter.
 *
 */
public class BurstGroup extends TestMethod {
    /** Main object for the test execution */
    public IMeasurement measurement;
    /** Path to the specification file that should be imported */
    @In public String specFileToImport = "crossconnect.common.SignalGroups";
    /** Functional test descriptor for datalog */
    public IFunctionalTestDescriptor mainFtd;
    /** Define parameter group for list of patterns to be bursted */
    static public class PatternSetting extends ParameterGroup {
        // LAB: Add member variables for the parameter group as shown
        // in the presentation on test method parameters
    }
    /** List of patterns to be bursted */
    @In public ParameterGroupCollection<PatternSetting>
    patternGroup = new ParameterGroupCollection<>();
    /** Output parameter to return pass/fail result of execution */
    @Out public MultiSiteBoolean results = null;
    /** Signals configured as digInOut as part of the patterns and to be tested for pass/fail */
    @In public String signalsInPattern = "D00 + D01 + D02 + D03 + D04 + R00 + R01 + R02 + R03";
    /** Signals configured as dcVi with voltage measurement */
    @In public String signalsToMeasure = "R04";

    @Override
    public void setup() {
        // Check, if any pattern is provided as input
        if (patternGroup.isEmpty()) {
            throw new UncheckedDTAException("[" + getClass().getName() + ": line "
                    + new Exception().getStackTrace()[0].getLineNumber()
                    + "] Input parameter 'patternGroup' is empty in test suite '" + context.getTestSuiteName()  +
                    "'. Please assign at least one pattern.");
        }
        // Check, if test signals are valid
        if (signalsInPattern.trim().isEmpty()) {
            throw new UncheckedDTAException("[" + getClass().getName() + ": line "
                    + new Exception().getStackTrace()[0].getLineNumber()
                    + "] Input parameter 'testSignals' (value '" + signalsInPattern
                    + "' ) is empty in test suite '" + context.getTestSuiteName() + "'.");
        }

        // LAB: Insert from test method "ProgrammaticTestSetup.java":
        // Create setup of digInOut and dcVI signals, import specification file

        // LAB: Build operating sequence as shown in the presentation on test method parameters

        // LAB: Insert: Make the generated setup to become valid for the current measurement
    }

    @Override
    public void update() {
        // LAB: Insert: Enable for "signalsInPattern" the call pass/fail when log level is 30 and higher.

        // Set loglevel of test per pattern to the loglevel of the main test descriptor
        // LAB: Make the following three lines valid by removing "//"
        // for (PatternSetting singleGroup : patternGroup.values()) {
        //     singleGroup.patternFtd.setLogLevel(mainFtd.getLogLevel());
        // }

    }

    @Override
    public void execute() {
        // run measurement
        measurement.execute();

        // protect results to be not overwritten
        IMeasurementResult measurementResults = measurement.preserveResult();
        // LAB: Make the following four lines valid by removing "//"
        // IDigInOutCallPassFailResults callPassFailResults = null;
        // if (mainFtd.getLogLevel() >= 30) {
        //     callPassFailResults = measurement.digInOut(signalsInPattern).preserveCallPassFailResults();
        // }

        // next test suite can start and use tester resources
        releaseTester();

        // LAB: Add: Check if pass/fail results have been retrieved
        // If yes, then retrieve results per pattern with "getPatternPassFail()"
        // If yes, then evaluate results as shown in the presentation on test method parameters

        // for all sites: check global pass/fail and send results to datalog
        mainFtd.evaluate(measurementResults);

        // set output parameter: pass/fail result of execution
        results = mainFtd.getPassFail();
    }

    // LAB: Insert: Function to define the wavetable

}
